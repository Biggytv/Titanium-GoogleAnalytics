Alloy.Globals.GoogleAnalytics = require('GoogleAnalytics').GoogleAnalytics;
Alloy.Globals.GoogleAnalytics && Alloy.Globals.GoogleAnalytics.init('UA-XXXXXXXX-Y');

